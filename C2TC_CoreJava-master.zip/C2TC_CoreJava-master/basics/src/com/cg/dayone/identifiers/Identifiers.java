package com.cg.dayone.identifiers;

public class Identifiers {
	 public static void main(String[] args)
	    {
		 int main = 5;
		 System.out.println("value of the number variable is : "+ main);
	    }
	

}
