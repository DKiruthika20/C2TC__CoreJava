package com.cg.dayone.identifiers;

public class primitivedatatypes {
 public static void main(String[] args) {
	// boolean type
	    boolean flag = true;
	    System.out.println(flag); 
	// byte type
	    byte range;
	    range = 125;
	    System.out.println(range);
	// short type
	    short temperature;
	    temperature = 34;
	    System.out.println(temperature);
	// int datatype
	    int range1 = 876396;
	    System.out.println(range1);
	// long type
	    long range2 = 42332200000L;
	    System.out.println(range2);
	//double type
	    double number = -42.3;
	    System.out.println(number); 
	//float type
	    float number1 = 42.3f;
	    System.out.println(number1);
	//char type
	    char letter = '\u0055';
	    System.out.println(letter);
	    }
}
