package com.cg.dayone.identifiers;

public class chardemo {
	public static void main(String[] args) {
		char ch='a';
		System.out.println(ch);
		int num='5';
		System.out.println(num);
		char var1='\u00A9';
		System.out.println(var1);
		char var2='\u20AC';
		System.out.println(var2);
		int a='B';
		System.out.println(a);
		
	}

}
