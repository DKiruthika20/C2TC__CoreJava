package com.cg.dayone.identifiers;

public class emoji {

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			System.out.println("\uD83D\uDE00");
		

		}


}
