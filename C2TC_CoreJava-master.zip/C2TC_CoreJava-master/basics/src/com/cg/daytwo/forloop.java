package com.cg.daytwo;

public class forloop {
	public static void main(String[] args) {
		for (int i = 0; i <= 10; i = i+3) {
			  System.out.println(i);
			}
	}

}
