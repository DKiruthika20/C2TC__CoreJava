package com.cg.daytwo;

public class ifelse {
	public static void main(String[] args) {
		int time=24;
		if(time<12) {
			System.out.println("good morning");
		}
		else if(time>=12 && time<=17) {
			System.out.println("good evening ");
		}
		else {
			System.out.println("good night");
		}
		
	}

}
