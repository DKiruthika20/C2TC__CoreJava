package com.cg.daytwo;

public class foreachloop {
	public static void main(String[] args) {
		String[] names = {"Kirthi", "Kavi", "Subi", "Abi"};
		for (String i : names) {
		  System.out.println(i);
		}
	}

}
