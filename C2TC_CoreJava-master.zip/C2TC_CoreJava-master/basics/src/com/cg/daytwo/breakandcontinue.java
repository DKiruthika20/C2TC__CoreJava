package com.cg.daytwo;

public class breakandcontinue {
	public static void main(String[] args) {
	//break
	 for(int i=1;i<=20;i++){  
	        if(i==10){   
	            break;  
	        }  
	        System.out.println(i);

	 }
	 //continue   
		    for(int i=1;i<=15;i++){  
		        if(i==15){    
		            continue;
}
		    }
	}
}
