package basics;

public class firstprogram {
	public static void main(String[] args) {
		System.out.println("HI IFET");
	}

}
